import java.util.ArrayList;

public interface BestScoreStrategy {
    public Student getBestScore(ArrayList<Grade> grades);
}
